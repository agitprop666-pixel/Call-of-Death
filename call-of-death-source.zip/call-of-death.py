#!/usr/bin/env python3
"""
Call of Death - Peer-to-Peer Video & Audio Chat
Designed for ZeroTier and Tailscale VPN Networks
Death's Head Software
v1.0
"""

import sys
import time
import socket
import os
import struct
import threading
import wave
from pathlib import Path
from enum import IntEnum

# ---------------------------------------------------------------------------
# Helper Functions
# ---------------------------------------------------------------------------

def resource_path(relative_path):
    """Get absolute path to resource — works for dev and PyInstaller."""
    try:
        base_path = sys._MEIPASS
    except AttributeError:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)


def format_bytes(n):
    """Human-readable byte count."""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if n < 1024.0:
            return f"{n:.1f} {unit}"
        n /= 1024.0
    return f"{n:.1f} TB"


def load_app_icon():
    """Load icon.ico or fall back to splash.png."""
    from PyQt6.QtGui import QIcon
    for name in ["icon.ico", "splash.png"]:
        p = Path(resource_path(name))
        if p.exists():
            return QIcon(str(p))
    return None


def get_all_local_ips():
    """
    Detect ALL local IP addresses including VPN/Tailscale/ZeroTier interfaces.
    Uses multiple strategies to find IPs that hostname-based lookups miss.
    """
    ips = []

    # Method 1: hostname lookup
    try:
        hostname = socket.gethostname()
        for info in socket.getaddrinfo(hostname, None, socket.AF_INET):
            ip = info[4][0]
            if ip != '127.0.0.1' and ip not in ips:
                ips.append(ip)
    except Exception:
        pass

    # Method 2: routing-based (finds main outbound IP)
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        if ip not in ips:
            ips.insert(0, ip)
    except Exception:
        pass

    # Method 3: probe multiple routing targets to discover VPN interfaces
    for target in [
        ("1.1.1.1", 80),       # Public internet
        ("100.64.0.1", 80),    # Tailscale CGNAT range (100.x.x.x)
        ("10.0.0.1", 80),      # Common ZeroTier / VPN range
        ("192.168.1.1", 80),   # Common home LAN
        ("172.16.0.1", 80),    # Common corporate / ZeroTier range
    ]:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(target)
            ip = s.getsockname()[0]
            s.close()
            if ip not in ips and ip != '127.0.0.1':
                ips.append(ip)
        except Exception:
            pass

    return ips or ["127.0.0.1"]


def tag_ip(ip: str) -> str:
    """Return a descriptive tag for a known VPN IP range."""
    if ip.startswith('100.'):
        return "← Tailscale"
    if ip.startswith('10.') or (ip.startswith('172.') and 16 <= int(ip.split('.')[1]) <= 31):
        return "← ZeroTier / VPN"
    if ip.startswith('192.168.'):
        return "← LAN"
    return ""


# ---------------------------------------------------------------------------
# Globals
# ---------------------------------------------------------------------------

APP_NAME = "Call of Death"
ORG_NAME = "Death's Head Software"
DEFAULT_PORT = 8765


class DataPacketType(IntEnum):
    CHAT     = 1
    MEDIA    = 2
    NICKNAME = 3


# ---------------------------------------------------------------------------
# Imports
# ---------------------------------------------------------------------------

try:
    from PyQt6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
        QTextEdit, QPushButton, QLabel, QLineEdit, QTabWidget,
        QSplitter, QSplashScreen, QGroupBox, QListWidget,
        QAbstractItemView, QComboBox, QScrollArea, QMessageBox,
    )
    from PyQt6.QtCore import Qt, QThread, pyqtSignal, QSettings
    from PyQt6.QtGui import QPixmap, QPainter, QColor, QFont, QAction, QImage
    LIBS_AVAILABLE = True
except ImportError as e:
    LIBS_AVAILABLE = False
    print(f"FATAL: pip install PyQt6.  Details: {e}")
    sys.exit(1)


# ===========================================================================
# HARDWARE MANAGER
# ===========================================================================

def _request_macos_av_permissions(on_complete):
    """
    Request macOS camera + microphone permissions via AVFoundation before any
    hardware access.  Calls on_complete() (a zero-arg callable) when done —
    either after grants are confirmed, or immediately on non-macOS platforms.

    Requires pyobjc-framework-AVFoundation (pre-installed on macOS system Python
    and includable in PyInstaller bundles via --collect-all AVFoundation).
    Falls back gracefully if pyobjc is unavailable.

    Your PyInstaller .spec Info.plist MUST contain:
        'NSCameraUsageDescription':    'Used for video calls.',
        'NSMicrophoneUsageDescription':'Used for voice calls.',
    Without these keys macOS silently denies access regardless of this call.
    """
    if sys.platform != 'darwin':
        on_complete()
        return

    try:
        import objc  # noqa
        from AVFoundation import (
            AVCaptureDevice,
            AVMediaTypeVideo,
            AVMediaTypeAudio,
            AVAuthorizationStatusAuthorized,
            AVAuthorizationStatusNotDetermined,
        )
    except ImportError:
        print("⚠ pyobjc AVFoundation not available — skipping permission request")
        on_complete()
        return

    cam_status = AVCaptureDevice.authorizationStatusForMediaType_(AVMediaTypeVideo)
    mic_status = AVCaptureDevice.authorizationStatusForMediaType_(AVMediaTypeAudio)

    need_cam = (cam_status == AVAuthorizationStatusNotDetermined)
    need_mic = (mic_status == AVAuthorizationStatusNotDetermined)

    if not need_cam and not need_mic:
        # Already determined (granted or denied) — proceed immediately
        on_complete()
        return

    # We need at least one permission dialog — chain the requests then call on_complete
    def after_mic(_granted):
        from PyQt6.QtCore import QTimer
        QTimer.singleShot(0, on_complete)

    def after_cam(_granted):
        if need_mic:
            AVCaptureDevice.requestAccessForMediaType_completionHandler_(
                AVMediaTypeAudio, after_mic
            )
        else:
            from PyQt6.QtCore import QTimer
            QTimer.singleShot(0, on_complete)

    if need_cam:
        AVCaptureDevice.requestAccessForMediaType_completionHandler_(
            AVMediaTypeVideo, after_cam
        )
    else:
        AVCaptureDevice.requestAccessForMediaType_completionHandler_(
            AVMediaTypeAudio, after_mic
        )


class HardwareManager:
    """Detects cameras, microphones, and speakers."""

    def __init__(self, defer=False):
        self.cameras  = ["No Camera"]
        self.mics     = ["No Microphone"]
        self.speakers = ["No Speaker"]
        self.selected_camera  = "No Camera"
        self.selected_mic     = "No Microphone"
        self.selected_speaker = "No Speaker"
        if not defer:
            self.detect_all()

    def detect_all(self):
        """Run full detection — safe to call after QApplication is fully running."""
        self.detect_cameras()
        self.detect_microphones()
        self.detect_speakers()

    # --- Detection ----------------------------------------------------------

    def detect_cameras(self):
        self.cameras = ["No Camera"]
        os.environ.setdefault("OPENCV_LOG_LEVEL", "SILENT")

        # Try QMediaDevices for real descriptive names (requires PyQt6-Qt6-Multimedia)
        qt_names = []
        try:
            from PyQt6.QtMultimedia import QMediaDevices
            for dev in QMediaDevices.videoInputs():
                qt_names.append(dev.description())
        except Exception:
            pass

        try:
            import cv2
            # Always scan indices 0-3 regardless of qt_names length.
            # On Linux (V4L2) cap.read() during detection often fails due to slow
            # camera init — use isOpened() only for enumeration; streaming will
            # verify with a real read + warm-up frames.
            n = max(len(qt_names), 4)
            for i in range(n):
                if sys.platform == "linux":
                    backend = cv2.CAP_V4L2
                elif sys.platform == "win32":
                    backend = cv2.CAP_ANY
                else:
                    backend = cv2.CAP_ANY
                cap = cv2.VideoCapture(i, backend)
                if cap.isOpened():
                    cap.release()
                    label = qt_names[i] if i < len(qt_names) else f"Camera {i}"
                    self.cameras.append(f"{label} [{i}]")
        except Exception:
            pass

        self.selected_camera = self.cameras[1] if len(self.cameras) > 1 else self.cameras[0]

    def detect_microphones(self):
        self.mics = ["No Microphone"]
        try:
            import sounddevice as sd
            seen = set()
            for d in sd.query_devices():
                if d['max_input_channels'] > 0:
                    name = d['name'].strip()
                    if name not in seen:
                        self.mics.append(name)
                        seen.add(name)
        except Exception:
            pass
        self.selected_mic = self.mics[1] if len(self.mics) > 1 else self.mics[0]

    def detect_speakers(self):
        self.speakers = ["No Speaker"]
        try:
            import sounddevice as sd
            seen = set()
            for d in sd.query_devices():
                if d['max_output_channels'] > 0:
                    name = d['name'].strip()
                    if name not in seen:
                        self.speakers.append(name)
                        seen.add(name)
        except Exception:
            pass
        self.selected_speaker = self.speakers[1] if len(self.speakers) > 1 else self.speakers[0]

    # --- Selection ----------------------------------------------------------

    def select_camera(self, name: str):
        if name in self.cameras:
            self.selected_camera = name

    def select_mic(self, name: str):
        if name in self.mics:
            self.selected_mic = name

    def select_speaker(self, name: str):
        if name in self.speakers:
            self.selected_speaker = name

    # --- Tests --------------------------------------------------------------

    def test_camera(self):
        if self.selected_camera == "No Camera":
            return False, "No camera selected"
        try:
            import cv2
            import re as _re
            _cm = _re.search(r'\[(\d+)\]$', self.selected_camera) or \
                  _re.search(r'Camera\s+(\d+)$', self.selected_camera)
            if _cm:
                idx = int(_cm.group(1))
            if _cm:
                cap = cv2.VideoCapture(idx)
                if cap.isOpened():
                    ret, _ = cap.read()
                    cap.release()
                    return (True, "Camera OK") if ret else (False, "Capture failed")
        except Exception as e:
            return False, str(e)
        return False, "Unknown"

    def test_microphone(self):
        if self.selected_mic == "No Microphone":
            return False, "No microphone selected"
        try:
            import sounddevice as sd
            import numpy as np
            rec = sd.rec(int(0.5 * 44100), samplerate=44100, channels=1)
            sd.wait()
            avg = float(np.mean(np.abs(rec)))
            return True, f"Mic OK (avg level: {avg:.5f})"
        except Exception as e:
            return False, str(e)

    def test_speaker(self):
        if self.selected_speaker == "No Speaker":
            return False, "No speaker selected"
        try:
            import sounddevice as sd
            import numpy as np
            t    = np.linspace(0, 0.3, int(44100 * 0.3))
            tone = (0.3 * np.sin(2 * np.pi * 440 * t)).astype(np.float32)
            sd.play(tone, 44100, blocking=True)
            return True, "Beep played!"
        except Exception as e:
            return False, str(e)


# ===========================================================================
# PEER SOCKET
# ===========================================================================

class PeerSocket:
    """
    Thin TCP socket wrapper for peer communication.
    Protocol: 5-byte header  struct.pack('!BI', packet_type, payload_length)
              followed by payload_length bytes of payload.
    """

    def __init__(self, raw_socket: socket.socket = None):
        self.sock  = raw_socket
        self._lock = threading.Lock()
        if self.sock:
            self._configure()

    def _configure(self):
        try:
            self.sock.settimeout(3600)                                         # 1-hour idle timeout
            self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)   # Disable Nagle
            self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 8 * 1024 * 1024)
            self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 8 * 1024 * 1024)
            self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
            if hasattr(socket, 'TCP_KEEPIDLE'):
                self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPIDLE, 30)
            if hasattr(socket, 'TCP_KEEPINTVL'):
                self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPINTVL, 10)
            if hasattr(socket, 'TCP_KEEPCNT'):
                self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPCNT, 9)
            if sys.platform == 'win32':
                self.sock.ioctl(socket.SIO_KEEPALIVE_VALS, (1, 30000, 10000))
            print("PeerSocket: configured (8MB buffers, keepalive, 1hr timeout)")
        except Exception as e:
            print(f"PeerSocket: config warning — {e}")

    def connect(self, host: str, port: int):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((host, port))
        self._configure()

    def send_data(self, data: bytes, packet_type: DataPacketType):
        header = struct.pack('!BI', int(packet_type), len(data))
        with self._lock:
            self.sock.sendall(header + data)

    def recv_all(self, n: int) -> bytes:
        buf = bytearray()
        while len(buf) < n:
            chunk = self.sock.recv(min(65536, n - len(buf)))
            if not chunk:
                raise ConnectionError("Connection closed by peer")
            buf.extend(chunk)
        return bytes(buf)

    def receive_data(self):
        """Blocking read.  Returns (DataPacketType, bytes) or raises."""
        header = self.recv_all(5)
        ptype, length = struct.unpack('!BI', header)
        payload = self.recv_all(length) if length > 0 else b''
        return DataPacketType(ptype), payload

    def close(self):
        if self.sock:
            try:
                self.sock.shutdown(socket.SHUT_RDWR)
            except Exception:
                pass
            try:
                self.sock.close()
            except Exception:
                pass
            self.sock = None


# ===========================================================================
# MEDIA STREAMER
# ===========================================================================

class MediaStreamer(QThread):
    """Captures local camera + microphone and streams them to the peer."""

    def __init__(self, peer_socket: PeerSocket, hw_manager: HardwareManager):
        super().__init__()
        self.peer_socket  = peer_socket
        self.hw_manager   = hw_manager
        self.running      = False
        self.is_muted     = False
        self.video_enabled = True
        self.camera_cap   = None
        self.audio_device_idx = None
        self._init_hardware()

    def _init_hardware(self):
        # Camera — on Windows try backends in order and verify with a real frame read.
        # isOpened() returning True is NOT sufficient — DSHOW often lies on index-based
        # capture. We must confirm cap.read() actually delivers pixels.
        if self.hw_manager.selected_camera != "No Camera":
            try:
                import cv2
                import re as _re
                _cm = _re.search(r'\[(\d+)\]$', self.hw_manager.selected_camera) or \
                      _re.search(r'Camera\s+(\d+)$', self.hw_manager.selected_camera)
                if _cm:
                    idx = int(_cm.group(1))
                if _cm:
                    if sys.platform == "win32":
                        backends = [
                            (cv2.CAP_MSMF,  "MSMF"),
                            (cv2.CAP_ANY,   "ANY"),
                            (cv2.CAP_DSHOW, "DSHOW"),
                        ]
                    elif sys.platform == "linux":
                        backends = [
                            (cv2.CAP_V4L2, "V4L2"),
                            (cv2.CAP_ANY,  "ANY"),
                        ]
                    else:
                        backends = [(cv2.CAP_ANY, "ANY")]

                    for backend, bname in backends:
                        try:
                            cap = cv2.VideoCapture(idx, backend)
                            if not cap.isOpened():
                                cap.release()
                                print(f"Camera backend {bname}: isOpened=False, skipping")
                                continue
                            cap.set(cv2.CAP_PROP_FRAME_WIDTH,  480)
                            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 360)
                            cap.set(cv2.CAP_PROP_FPS, 15)
                            cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
                            # Drain stale frames, then confirm we get real pixels
                            for _ in range(5):
                                cap.grab()
                            ret, frame = cap.read()
                            if not ret or frame is None:
                                cap.release()
                                print(f"Camera backend {bname}: read() returned no frame, skipping")
                                continue
                            print(f"✓ Camera: {frame.shape[1]}x{frame.shape[0]} @ 15 fps ({bname})")
                            self.camera_cap = cap
                            break
                        except Exception as be:
                            print(f"Camera backend {bname} error: {be}")
                    else:
                        print("✗ Camera: no backend produced a valid frame")
            except Exception as e:
                print(f"Camera init error: {e}")

        # Microphone
        if self.hw_manager.selected_mic != "No Microphone":
            try:
                import sounddevice as sd
                for i, d in enumerate(sd.query_devices()):
                    if d['name'] in self.hw_manager.selected_mic and d['max_input_channels'] > 0:
                        self.audio_device_idx = i
                        print(f"✓ Mic: device {i} ({d['name']})")
                        break
            except Exception as e:
                print(f"Mic init error: {e}")

    def run(self):
        self.running = True
        audio_stream = None

        # Open audio input stream
        if not self.is_muted and self.audio_device_idx is not None:
            try:
                import sounddevice as sd
                SAMPLE_RATE = 16000
                CHUNK_MS    = 60
                frames      = int(SAMPLE_RATE * CHUNK_MS / 1000)
                audio_stream = sd.InputStream(
                    device     = self.audio_device_idx,
                    channels   = 1,
                    samplerate = SAMPLE_RATE,
                    blocksize  = frames,
                    dtype      = 'float32',
                )
                audio_stream.start()
                print(f"✓ Audio input: 16 kHz, {CHUNK_MS} ms chunks")
            except Exception as e:
                print(f"Audio stream init error: {e}")
                audio_stream = None

        while self.running:
            try:
                payload = b""

                # --- Audio capture -----------------------------------------
                # Framing: b'A' + uint32_be(length) + raw_bytes
                if not self.is_muted and audio_stream and audio_stream.active:
                    try:
                        data, _ = audio_stream.read(audio_stream.blocksize)
                        if data is not None and len(data) > 0:
                            ab = data.tobytes()
                            payload += b'A' + struct.pack('!I', len(ab)) + ab
                    except Exception:
                        pass

                # --- Video capture -----------------------------------------
                # Framing: b'V' + uint32_be(length) + jpeg_bytes
                if self.video_enabled and self.camera_cap and self.camera_cap.isOpened():
                    try:
                        import cv2
                        ret, frame = self.camera_cap.read()
                        if ret:
                            _, buf = cv2.imencode(
                                '.jpg', frame,
                                [cv2.IMWRITE_JPEG_QUALITY, 55],
                            )
                            vb = buf.tobytes()
                            payload += b'V' + struct.pack('!I', len(vb)) + vb
                    except Exception as e:
                        print(f"Video capture error: {e}")

                # --- Send ---------------------------------------------------
                if payload:
                    try:
                        self.peer_socket.send_data(payload, DataPacketType.MEDIA)
                    except Exception as e:
                        print(f"Media send error: {e}")
                        break

                time.sleep(0.067)   # ~15 fps pacing

            except Exception as e:
                print(f"MediaStreamer loop error: {e}")
                time.sleep(0.1)

        # Cleanup
        if audio_stream:
            try:
                audio_stream.stop()
                audio_stream.close()
            except Exception:
                pass

    def stop_stream(self):
        self.running = False
        if self.camera_cap:
            try:
                self.camera_cap.release()
            except Exception:
                pass
        self.wait()


# ===========================================================================
# AUDIO PLAYBACK
# ===========================================================================

class AudioPlayback(QThread):
    """Plays incoming audio chunks through the selected speaker."""

    SAMPLE_RATE = 16000
    CHUNK_MS    = 60

    def __init__(self, hw_manager: HardwareManager):
        super().__init__()
        self.hw_manager       = hw_manager
        self.running          = False
        self.audio_queue      = []
        self.lock             = threading.Lock()
        self.speaker_idx      = None
        self.frames_per_chunk = int(self.SAMPLE_RATE * self.CHUNK_MS / 1000)
        self._init_speaker()

    def _init_speaker(self):
        if self.hw_manager.selected_speaker == "No Speaker":
            print("⚠ AudioPlayback: no speaker selected")
            return
        try:
            import sounddevice as sd
            for i, d in enumerate(sd.query_devices()):
                if d['name'] in self.hw_manager.selected_speaker and d['max_output_channels'] > 0:
                    self.speaker_idx = i
                    print(f"✓ Speaker: device {i} ({d['name']})")
                    return
            # Fallback to default output
            self.speaker_idx = sd.default.device[1]
            print(f"✓ Speaker: using default output device {self.speaker_idx}")
        except Exception as e:
            print(f"Speaker init error: {e}")

    def add_audio(self, audio_bytes: bytes):
        """Enqueue an audio chunk for playback."""
        with self.lock:
            expected = self.frames_per_chunk * 4   # float32 = 4 bytes/sample
            if len(audio_bytes) == expected:
                self.audio_queue.append(audio_bytes)
            elif len(audio_bytes) > 0:
                import numpy as np
                arr = np.frombuffer(audio_bytes, dtype=np.float32)
                if len(arr) < self.frames_per_chunk:
                    arr = np.pad(arr, (0, self.frames_per_chunk - len(arr)))
                else:
                    arr = arr[:self.frames_per_chunk]
                self.audio_queue.append(arr.tobytes())
            # Cap queue to ~720 ms to keep latency low
            while len(self.audio_queue) > 12:
                self.audio_queue.pop(0)

    def run(self):
        self.running = True
        if self.speaker_idx is None:
            print("AudioPlayback: no speaker — thread idle")
            while self.running:
                time.sleep(0.1)
            return

        try:
            import sounddevice as sd
            import numpy as np

            # Pre-fill with silence to avoid underruns at startup
            silence = np.zeros(self.frames_per_chunk, dtype=np.float32)
            with self.lock:
                for _ in range(4):
                    self.audio_queue.append(silence.tobytes())

            def _callback(outdata, frames, time_info, status):
                chunk = None
                with self.lock:
                    if len(self.audio_queue) >= 4:
                        chunk = self.audio_queue.pop(0)
                if chunk:
                    arr = np.frombuffer(chunk, dtype=np.float32)
                    if len(arr) < frames:
                        arr = np.pad(arr, (0, frames - len(arr)))
                    elif len(arr) > frames:
                        arr = arr[:frames]
                    outdata[:] = arr.reshape(-1, 1)
                else:
                    outdata.fill(0)

            with sd.OutputStream(
                device    = self.speaker_idx,
                channels  = 1,
                samplerate= self.SAMPLE_RATE,
                blocksize = self.frames_per_chunk,
                dtype     = 'float32',
                callback  = _callback,
            ):
                print("✓✓✓ Audio playback stream ACTIVE ✓✓✓")
                while self.running:
                    time.sleep(0.1)

        except Exception as e:
            print(f"AudioPlayback error: {e}")
            while self.running:
                time.sleep(0.1)

    def stop(self):
        self.running = False
        with self.lock:
            self.audio_queue.clear()
        # Do NOT call sd.stop() — on macOS Core Audio crashes if you abort
        # an OutputStream from outside its own callback thread. Setting
        # self.running = False lets run() exit the OutputStream context cleanly.
        self.wait()


# ===========================================================================
# SERVER LISTENER
# ===========================================================================

class ServerListener(QThread):
    """Listens for incoming TCP connections and emits PeerSocket objects."""

    new_connection = pyqtSignal(object)   # PeerSocket

    def __init__(self, port: int):
        super().__init__()
        self.port          = port
        self.running       = True
        self.server_socket = None

    def stop(self):
        self.running = False
        if self.server_socket:
            try:
                self.server_socket.close()
            except Exception:
                pass

    def run(self):
        try:
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_socket.bind(('0.0.0.0', self.port))
            self.server_socket.listen(5)
            self.server_socket.settimeout(1.0)
            print(f"✓ Server listening on port {self.port}")

            while self.running:
                try:
                    client_sock, addr = self.server_socket.accept()
                    print(f"Incoming connection from {addr[0]}:{addr[1]}")
                    self.new_connection.emit(PeerSocket(client_sock))
                except socket.timeout:
                    continue
                except Exception as e:
                    if self.running:
                        print(f"Accept error: {e}")
        except Exception as e:
            print(f"Server error: {e}")


# ===========================================================================
# SOCKET LISTENER
# ===========================================================================

class SocketListener(QThread):
    """Reads packets from a connected PeerSocket and dispatches signals."""

    new_message            = pyqtSignal(bytes)
    new_media              = pyqtSignal(bytes)
    peer_nickname_received = pyqtSignal(bytes)
    connection_lost        = pyqtSignal(str)

    def __init__(self, peer_socket: PeerSocket):
        super().__init__()
        self.peer_socket = peer_socket
        self.running     = True

    def stop(self):
        self.running = False

    def run(self):
        print("SocketListener: started")
        while self.running:
            try:
                ptype, payload = self.peer_socket.receive_data()
                if ptype == DataPacketType.CHAT:
                    self.new_message.emit(payload)
                elif ptype == DataPacketType.MEDIA:
                    self.new_media.emit(payload)
                elif ptype == DataPacketType.NICKNAME:
                    self.peer_nickname_received.emit(payload)
            except (ConnectionError, ConnectionResetError, ConnectionAbortedError, OSError) as e:
                self.connection_lost.emit(f"Connection lost: {type(e).__name__}")
                break
            except Exception as e:
                if self.running:
                    self.connection_lost.emit(f"Listener error: {e}")
                break
        print("SocketListener: stopped")


# ===========================================================================
# VIDEO WIDGET — custom QWidget to display video frames on all platforms.
# Using QLabel+stylesheet causes Windows Qt style engine to overpaint the
# pixmap with background-color after every repaint, producing a black frame.
# VideoWidget owns its own paintEvent so nothing can overpaint it.
# ===========================================================================

class VideoWidget(QWidget):
    def __init__(self, placeholder="", parent=None):
        super().__init__(parent)
        self._pixmap      = None
        self._placeholder = placeholder
        self.setMinimumSize(420, 280)
        # Tell Qt this widget paints its own entire surface — no background fill
        self.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent, True)

    def set_pixmap(self, pm: QPixmap):
        self._pixmap = pm
        self.update()

    def clear(self):
        self._pixmap = None
        self.update()

    def setText(self, text: str):        # drop-in compat with QLabel.setText
        self._placeholder = text
        self._pixmap      = None
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        # Step 1: solid black background — always, no style engine involved
        painter.fillRect(self.rect(), QColor(0, 0, 0))
        # Step 2: draw pixmap if we have one, centered with aspect ratio
        if self._pixmap and not self._pixmap.isNull():
            scaled = self._pixmap.scaled(
                self.size(),
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
            x = (self.width()  - scaled.width())  // 2
            y = (self.height() - scaled.height()) // 2
            painter.drawPixmap(x, y, scaled)
        elif self._placeholder:
            painter.setPen(QColor(100, 100, 100))
            painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, self._placeholder)
        painter.end()


# ===========================================================================
# MAIN WINDOW — CALL OF DEATH
# ===========================================================================

class CallOfDeath(QMainWindow):

    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} v1.0")

        # Windows AppUserModelID for correct taskbar grouping
        if sys.platform == 'win32':
            try:
                import ctypes
                ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
                    f"{ORG_NAME}.{APP_NAME}.1.0"
                )
            except Exception:
                pass

        icon = load_app_icon()
        if icon:
            self.setWindowIcon(icon)

        # Settings / geometry
        self.settings = QSettings(ORG_NAME, APP_NAME)
        geom = self.settings.value("geometry")
        if geom:
            self.restoreGeometry(geom)
        else:
            self.setGeometry(100, 100, 1150, 780)
        self.setMinimumSize(900, 650)

        # Persisted preferences
        self.local_nickname = self.settings.value("nickname",     "Anonymous",  type=str)
        self.server_port    = self.settings.value("server_port",  DEFAULT_PORT, type=int)
        saved_camera  = self.settings.value("selected_camera")
        saved_mic     = self.settings.value("selected_mic")
        saved_speaker = self.settings.value("selected_speaker")

        # Hardware — use defer=True so no cv2/sounddevice calls happen during
        # __init__. Real detection runs via QTimer after the window is shown,
        # avoiding silent crashes in PyInstaller .app bundles on macOS where
        # cv2.VideoCapture() before the event loop is running can hard-kill
        # the process before any Python exception can be caught.
        self._saved_camera  = saved_camera
        self._saved_mic     = saved_mic
        self._saved_speaker = saved_speaker
        self.hw_manager = HardwareManager(defer=True)

        # Network state
        self.local_ips          = get_all_local_ips()
        self.peer_nickname      = "Peer"
        self.current_peer_socket: PeerSocket = None
        self.server_listener:    ServerListener = None
        self.listener_thread:    SocketListener = None
        self.media_streamer:     MediaStreamer  = None
        self.audio_playback:     AudioPlayback  = None

        # Recording state
        self.is_recording            = False
        self.video_writer            = None
        self.recording_filename      = ""
        self.audio_recording_filename= ""
        self.audio_recording_data    = []

        # Latest decoded frame waiting to be painted (set from signal handler,
        # consumed by a QTimer — decouples network rate from repaint rate)
        self._pending_frame: QPixmap = None

        # Build UI
        self.create_menu_bar()
        self.init_ui()
        self.apply_dark_theme()
        self.start_server()

        # Defer hardware detection until after the event loop starts.
        # On macOS in a .app bundle, cv2.VideoCapture() called before the
        # window is fully running can trigger a hard OS-level process kill
        # (camera permission check) with no catchable Python exception.
        from PyQt6.QtCore import QTimer as _QT
        _QT.singleShot(500, self._detect_hardware_deferred)

        # 30 ms repaint timer — fires in the main thread, owns all setPixmap calls
        from PyQt6.QtCore import QTimer
        self._frame_timer = QTimer(self)
        self._frame_timer.timeout.connect(self._paint_pending_frame)
        self._frame_timer.start(30)

    # -----------------------------------------------------------------------
    # Close / save
    # -----------------------------------------------------------------------

    def _detect_hardware_deferred(self):
        """
        Runs 500ms after startup — requests macOS permissions first, then
        detects cameras/mics/speakers after grants are confirmed.
        """
        self.status_label.setText("Status: Checking hardware permissions…")
        QApplication.processEvents()
        _request_macos_av_permissions(self._run_hardware_detection)

    def _run_hardware_detection(self):
        """Called after macOS permissions are granted (or immediately on other platforms)."""
        try:
            self.status_label.setText("Status: Detecting hardware…")
            QApplication.processEvents()
            self.hw_manager.detect_all()

            # Apply saved preferences
            if self._saved_camera  and self._saved_camera  in self.hw_manager.cameras:
                self.hw_manager.select_camera(self._saved_camera)
            if self._saved_mic     and self._saved_mic     in self.hw_manager.mics:
                self.hw_manager.select_mic(self._saved_mic)
            if self._saved_speaker and self._saved_speaker in self.hw_manager.speakers:
                self.hw_manager.select_speaker(self._saved_speaker)

            # Refresh device combo boxes with detected devices
            self.camera_combo.blockSignals(True)
            self.camera_combo.clear()
            self.camera_combo.addItems(self.hw_manager.cameras)
            self.camera_combo.setCurrentText(self.hw_manager.selected_camera)
            self.camera_combo.blockSignals(False)

            self.mic_combo.blockSignals(True)
            self.mic_combo.clear()
            self.mic_combo.addItems(self.hw_manager.mics)
            self.mic_combo.setCurrentText(self.hw_manager.selected_mic)
            self.mic_combo.blockSignals(False)

            self.speaker_combo.blockSignals(True)
            self.speaker_combo.clear()
            self.speaker_combo.addItems(self.hw_manager.speakers)
            self.speaker_combo.setCurrentText(self.hw_manager.selected_speaker)
            self.speaker_combo.blockSignals(False)

            self.status_label.setText(
                f"Status: Listening on port {self.server_port} — awaiting peer…"
            )
            print(f"✓ Hardware detected: "
                  f"cam={self.hw_manager.selected_camera} "
                  f"mic={self.hw_manager.selected_mic} "
                  f"spk={self.hw_manager.selected_speaker}")
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.status_label.setText(f"Status: Hardware detection error: {e}")

    def closeEvent(self, event):
        self.settings.setValue("geometry",        self.saveGeometry())
        self.settings.setValue("nickname",        self.local_nickname)
        self.settings.setValue("server_port",     self.server_port)
        self.settings.setValue("selected_camera", self.hw_manager.selected_camera)
        self.settings.setValue("selected_mic",    self.hw_manager.selected_mic)
        self.settings.setValue("selected_speaker",self.hw_manager.selected_speaker)

        if self.is_recording and self.video_writer:
            self.video_writer.release()
            self.video_writer = None
        self.audio_recording_data = []

        self._teardown_connection()

        if self.server_listener:
            self.server_listener.stop()
            self.server_listener.wait(2000)

        event.accept()

    # -----------------------------------------------------------------------
    # Menu bar
    # -----------------------------------------------------------------------

    def create_menu_bar(self):
        mb = self.menuBar()

        file_menu = mb.addMenu("&File")
        hw_action = QAction("Test Camera / Mic / Speaker", self)
        hw_action.triggered.connect(self.test_all_hardware)
        file_menu.addAction(hw_action)
        file_menu.addSeparator()
        exit_action = QAction("Exit", self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)

        help_menu = mb.addMenu("&Help")
        about_action = QAction(f"About {APP_NAME}", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)

    # -----------------------------------------------------------------------
    # UI construction
    # -----------------------------------------------------------------------

    def init_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(6, 6, 6, 4)
        root.setSpacing(4)

        self.tabs = QTabWidget()
        root.addWidget(self.tabs)

        self.tabs.addTab(self.create_connection_tab(), "📡  Connection")
        self.tabs.addTab(self.create_meeting_tab(),    "🎥  Meeting Room")
        self.tabs.addTab(self.create_chat_tab(),       "💬  Chat")
        self.tabs.addTab(self.create_diagnostics_tab(),"🔧  Diagnostics")

        self.status_label = QLabel(
            f"Status: Starting server on port {self.server_port}…"
        )
        self.status_label.setFont(QFont("Arial", 9))
        root.addWidget(self.status_label)

    # -----------------------------------------------------------------------
    # Tab: Connection
    # -----------------------------------------------------------------------

    def create_connection_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setSpacing(10)

        # --- Your IPs -------------------------------------------------------
        ip_group = QGroupBox("Network Identity")
        ip_layout = QVBoxLayout(ip_group)

        ip_row = QHBoxLayout()
        ips_text = "  |  ".join(self.local_ips) if len(self.local_ips) <= 3 \
                   else "\n".join(self.local_ips)
        self.local_ip_label = QLabel(f"Your IPs:  {ips_text}")
        self.local_ip_label.setFont(QFont("Courier", 10, QFont.Weight.Bold))
        self.local_ip_label.setWordWrap(True)
        ip_row.addWidget(self.local_ip_label, stretch=1)

        refresh_btn = QPushButton("Refresh IPs")
        refresh_btn.setMaximumWidth(110)
        refresh_btn.clicked.connect(self.refresh_local_ips)
        ip_row.addWidget(refresh_btn)
        ip_layout.addLayout(ip_row)

        port_row = QHBoxLayout()
        port_row.addWidget(QLabel("Listen Port:"))
        self.port_input = QLineEdit(str(self.server_port))
        self.port_input.setMaximumWidth(80)
        port_row.addWidget(self.port_input)
        apply_btn = QPushButton("Apply Port")
        apply_btn.setMaximumWidth(100)
        apply_btn.clicked.connect(self.restart_server)
        port_row.addWidget(apply_btn)
        port_row.addStretch()
        ip_layout.addLayout(port_row)
        layout.addWidget(ip_group)

        # --- Nickname -------------------------------------------------------
        nick_group = QGroupBox("Identity")
        nick_layout = QHBoxLayout(nick_group)
        nick_layout.addWidget(QLabel("Nickname:"))
        self.nickname_input = QLineEdit(self.local_nickname)
        self.nickname_input.setMaximumWidth(220)
        nick_layout.addWidget(self.nickname_input)
        set_btn = QPushButton("Set")
        set_btn.setMaximumWidth(60)
        set_btn.clicked.connect(self.set_nickname)
        nick_layout.addWidget(set_btn)
        nick_layout.addStretch()
        layout.addWidget(nick_group)

        # --- Connect --------------------------------------------------------
        conn_group = QGroupBox("Connect to Peer")
        conn_layout = QVBoxLayout(conn_group)

        hint = QLabel(
            "💡  Share your IP above with your peer.  "
            "Use the Tailscale IP (100.x.x.x) or ZeroTier IP (10.x.x.x / 172.x.x.x) "
            "for reliable NAT-traversal-free calls."
        )
        hint.setWordWrap(True)
        hint.setStyleSheet("color: #aaa; font-style: italic;")
        conn_layout.addWidget(hint)

        peer_row = QHBoxLayout()
        peer_row.addWidget(QLabel("Peer IP:"))
        self.peer_ip_input = QLineEdit()
        self.peer_ip_input.setPlaceholderText(
            "e.g. 100.x.x.x (Tailscale)  or  10.x.x.x (ZeroTier)"
        )
        peer_row.addWidget(self.peer_ip_input)
        peer_row.addWidget(QLabel("Port:"))
        self.peer_port_input = QLineEdit(str(self.server_port))
        self.peer_port_input.setMaximumWidth(80)
        peer_row.addWidget(self.peer_port_input)

        self.connect_button = QPushButton("📞  Call")
        self.connect_button.setMinimumWidth(90)
        self.connect_button.clicked.connect(self.connect_to_peer)
        peer_row.addWidget(self.connect_button)

        self.disconnect_button = QPushButton("📵  Hang Up")
        self.disconnect_button.setMinimumWidth(90)
        self.disconnect_button.setEnabled(False)
        self.disconnect_button.setStyleSheet(
            "QPushButton { background-color: #8B0000; color: white; "
            "border: none; padding: 8px 16px; border-radius: 4px; }"
            "QPushButton:hover { background-color: #cc0000; }"
            "QPushButton:disabled { background-color: #555; color: #888; }"
        )
        self.disconnect_button.clicked.connect(self.disconnect_peer)
        peer_row.addWidget(self.disconnect_button)

        conn_layout.addLayout(peer_row)
        layout.addWidget(conn_group)

        layout.addStretch()
        return tab

    # -----------------------------------------------------------------------
    # Tab: Meeting Room
    # -----------------------------------------------------------------------

    def create_meeting_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        splitter = QSplitter(Qt.Orientation.Horizontal)

        # --- Left: video feeds + controls -----------------------------------
        video_area   = QWidget()
        video_layout = QVBoxLayout(video_area)
        video_layout.setSpacing(6)

        # Peer video — VideoWidget (not QLabel) avoids Windows style-engine
        # background overpaint that makes setPixmap frames appear black.
        self.video_display = VideoWidget("Waiting for peer video stream…")
        self.video_display.setStyleSheet("border: 1px solid #4CAF50;")
        video_layout.addWidget(self.video_display, stretch=3)

        # Status indicators
        self.video_status_label = QLabel("Video: LIVE 📹")
        self.video_status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.video_status_label.setStyleSheet("color: #4CAF50; font-weight: bold;")
        video_layout.addWidget(self.video_status_label)

        self.mic_status_label = QLabel("Microphone: ACTIVE 🎙️")
        self.mic_status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.mic_status_label.setStyleSheet("color: #4CAF50; font-weight: bold;")
        video_layout.addWidget(self.mic_status_label)

        # Controls row
        ctrl = QWidget()
        ctrl_layout = QHBoxLayout(ctrl)
        ctrl_layout.setContentsMargins(0, 0, 0, 0)

        self.mic_toggle = QPushButton("🔇  Mute")
        self.mic_toggle.setCheckable(True)
        self.mic_toggle.toggled.connect(self.update_mic_indicator)

        self.cam_toggle = QPushButton("📷  Stop Video")
        self.cam_toggle.setCheckable(True)
        self.cam_toggle.toggled.connect(self.update_video_indicator)

        self.record_button = QPushButton("⏺️  Record")
        self.record_button.setCheckable(True)
        self.record_button.toggled.connect(self.toggle_recording)
        self.record_button.setEnabled(False)

        ctrl_layout.addWidget(self.mic_toggle)
        ctrl_layout.addWidget(self.cam_toggle)
        ctrl_layout.addWidget(self.record_button)
        ctrl_layout.addStretch()
        video_layout.addWidget(ctrl)

        splitter.addWidget(video_area)

        # --- Right: device config + peer list --------------------------------
        config        = QWidget()
        config_layout = QVBoxLayout(config)
        config_layout.setSpacing(8)

        dev_group  = QGroupBox("Devices")
        dev_layout = QVBoxLayout(dev_group)

        # Camera row
        cam_row = QHBoxLayout()
        cam_row.addWidget(QLabel("Camera:"))
        self.camera_combo = QComboBox()
        self.camera_combo.addItems(self.hw_manager.cameras)
        self.camera_combo.setCurrentText(self.hw_manager.selected_camera)
        self.camera_combo.currentIndexChanged.connect(self.update_camera_selection)
        cam_row.addWidget(self.camera_combo)
        cam_test = QPushButton("Test")
        cam_test.setMaximumWidth(50)
        cam_test.clicked.connect(self.test_camera)
        cam_row.addWidget(cam_test)
        dev_layout.addLayout(cam_row)

        # Mic row
        mic_row = QHBoxLayout()
        mic_row.addWidget(QLabel("Mic:"))
        self.mic_combo = QComboBox()
        self.mic_combo.addItems(self.hw_manager.mics)
        self.mic_combo.setCurrentText(self.hw_manager.selected_mic)
        self.mic_combo.currentIndexChanged.connect(self.update_mic_selection)
        mic_row.addWidget(self.mic_combo)
        mic_test = QPushButton("Test")
        mic_test.setMaximumWidth(50)
        mic_test.clicked.connect(self.test_microphone)
        mic_row.addWidget(mic_test)
        dev_layout.addLayout(mic_row)

        # Speaker row
        spk_row = QHBoxLayout()
        spk_row.addWidget(QLabel("Speaker:"))
        self.speaker_combo = QComboBox()
        self.speaker_combo.addItems(self.hw_manager.speakers)
        self.speaker_combo.setCurrentText(self.hw_manager.selected_speaker)
        self.speaker_combo.currentIndexChanged.connect(self.update_speaker_selection)
        spk_row.addWidget(self.speaker_combo)
        spk_test = QPushButton("Test")
        spk_test.setMaximumWidth(50)
        spk_test.clicked.connect(self.test_speaker)
        spk_row.addWidget(spk_test)
        dev_layout.addLayout(spk_row)

        config_layout.addWidget(dev_group)

        config_layout.addWidget(QLabel("Active Peer:"))
        self.peer_list = QListWidget()
        self.peer_list.addItem("(not connected)")
        config_layout.addWidget(self.peer_list)

        splitter.addWidget(config)
        splitter.setSizes([760, 320])
        layout.addWidget(splitter)

        return tab

    # -----------------------------------------------------------------------
    # Tab: Chat
    # -----------------------------------------------------------------------

    def create_chat_tab(self):
        tab    = QWidget()
        layout = QVBoxLayout(tab)

        self.chat_history = QTextEdit()
        self.chat_history.setReadOnly(True)
        layout.addWidget(self.chat_history)

        row = QHBoxLayout()
        self.chat_input = QLineEdit()
        self.chat_input.setPlaceholderText("Type a message and press Enter…")
        self.chat_input.returnPressed.connect(self.send_message)
        self.send_button = QPushButton("Send")
        self.send_button.setEnabled(False)
        self.send_button.clicked.connect(self.send_message)
        row.addWidget(self.chat_input)
        row.addWidget(self.send_button)
        layout.addLayout(row)

        return tab

    # -----------------------------------------------------------------------
    # Tab: Diagnostics  (ported from Transfer of Death)
    # -----------------------------------------------------------------------

    def create_diagnostics_tab(self):
        outer = QWidget()
        outer_layout = QVBoxLayout(outer)
        outer_layout.setContentsMargins(0, 0, 0, 0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        inner  = QWidget()
        layout = QVBoxLayout(inner)
        layout.setSpacing(10)

        BTN = """
            QPushButton {
                background-color: #0d7377; color: #fff; font-size: 13px;
                font-weight: bold; border: none; padding: 10px 16px; border-radius: 4px;
            }
            QPushButton:hover   { background-color: #14a085; }
            QPushButton:pressed { background-color: #0a5558; }
        """
        RED_BTN = """
            QPushButton {
                background-color: #8B0000; color: #fff; font-size: 13px;
                font-weight: bold; border: none; padding: 10px 16px; border-radius: 4px;
            }
            QPushButton:hover   { background-color: #cc0000; }
            QPushButton:pressed { background-color: #600000; }
        """

        # Step 1 — Self-test -------------------------------------------------
        g1     = QGroupBox("Step 1 — Test Your Own Server")
        l1     = QVBoxLayout(g1)
        l1.addWidget(QLabel(
            "Checks that your server is actually listening and accepting connections."
        ))
        b1 = QPushButton("Run Self-Test  (connect to localhost)")
        b1.setStyleSheet(BTN)
        b1.clicked.connect(self.run_self_test)
        l1.addWidget(b1)
        self.selftest_result = QLabel("Result: not run yet")
        self.selftest_result.setWordWrap(True)
        l1.addWidget(self.selftest_result)
        layout.addWidget(g1)

        # Step 2 — Peer reachability -----------------------------------------
        g2 = QGroupBox("Step 2 — Test Peer Reachability")
        l2 = QVBoxLayout(g2)
        l2.addWidget(QLabel(
            "Attempts a raw TCP connection to the peer IP:Port.  "
            "Does NOT require the app to be connected — just checks if the port is open."
        ))
        b2 = QPushButton("Test Peer Port  (uses IP / Port from Connection tab)")
        b2.setStyleSheet(BTN)
        b2.clicked.connect(self.run_reach_test)
        l2.addWidget(b2)
        self.reach_result = QLabel("Result: not run yet")
        self.reach_result.setWordWrap(True)
        l2.addWidget(self.reach_result)
        layout.addWidget(g2)

        # Step 3 — Network info & subnet check --------------------------------
        g3 = QGroupBox("Step 3 — Network Info & Subnet Check")
        l3 = QVBoxLayout(g3)
        b3 = QPushButton("Refresh Network Info")
        b3.setStyleSheet(BTN)
        b3.clicked.connect(self.refresh_netinfo)
        l3.addWidget(b3)
        self.netinfo_label = QLabel()
        self.netinfo_label.setWordWrap(True)
        self.netinfo_label.setFont(QFont("Courier", 9))
        l3.addWidget(self.netinfo_label)
        layout.addWidget(g3)

        # Common Issues -------------------------------------------------------
        g4     = QGroupBox("Common Issues")
        l4     = QVBoxLayout(g4)
        issues = QTextEdit()
        issues.setReadOnly(True)
        issues.setMaximumHeight(220)
        issues.setHtml("""
<b>❌ Not on the same VPN (most common!)</b><br>
Both peers must be on the same ZeroTier network or Tailscale tailnet.
Confirm you can <i>ping</i> each other's VPN IP before connecting.<br><br>

<b>❌ Wrong IP address</b><br>
Use the VPN IP shown in "Your IPs" in the Connection tab — not your LAN or public IP.<br>
&nbsp;&nbsp;• Tailscale IPs start with <b>100.x.x.x</b><br>
&nbsp;&nbsp;• ZeroTier IPs typically start with <b>10.x.x.x</b> or <b>172.x.x.x</b><br><br>

<b>❌ Firewall blocking the port</b><br>
Windows Firewall may block inbound connections even on a VPN adapter.<br>
Allow Python (or the .exe) for Private + Domain networks, or run this in PowerShell as Admin:<br>
<code>netsh advfirewall firewall add rule name="CallOfDeath" dir=in action=allow protocol=TCP localport=8765</code><br><br>

<b>❌ Port already in use</b><br>
Another process (or a crashed previous instance) may hold the port.<br>
Change the Listen Port in the Connection tab and click Apply Port.
        """)
        l4.addWidget(issues)
        layout.addWidget(g4)

        # Winsock repair (Windows only) ---------------------------------------
        g5 = QGroupBox("Windows — Repair Winsock  (fixes WinError 10013)")
        l5 = QVBoxLayout(g5)
        l5.addWidget(QLabel(
            "If you see WinError 10013, a VPN driver (Proton, Tailscale, ZeroTier) "
            "may have corrupted the Windows socket stack.\n"
            "Click below — a UAC prompt will appear.  You MUST reboot after the fix."
        ))
        b5 = QPushButton("Repair Winsock + Prompt Reboot  (Windows only)")
        b5.setStyleSheet(RED_BTN)
        b5.clicked.connect(self.repair_winsock)
        l5.addWidget(b5)
        self.winsock_result = QLabel("")
        self.winsock_result.setWordWrap(True)
        l5.addWidget(self.winsock_result)
        layout.addWidget(g5)
        if sys.platform != 'win32':
            g5.setVisible(False)

        layout.addStretch()
        scroll.setWidget(inner)
        outer_layout.addWidget(scroll)

        # Populate on first draw
        self.refresh_netinfo()

        return outer

    # -----------------------------------------------------------------------
    # Dark Theme
    # -----------------------------------------------------------------------

    def apply_dark_theme(self):
        self.setStyleSheet("""
            QMainWindow, QWidget {
                background-color: #1e1e1e;
                color: #e0e0e0;
            }
            QTabWidget::pane {
                border: 1px solid #333;
                background-color: #2d2d2d;
            }
            QTabBar::tab {
                background-color: #3c3c3c;
                color: #e0e0e0;
                padding: 8px 18px;
                border: 1px solid #555;
            }
            QTabBar::tab:selected {
                background-color: #2d2d2d;
                border-bottom: 2px solid #4CAF50;
            }
            QTextEdit, QLineEdit, QListWidget {
                background-color: #2d2d2d;
                color: #e0e0e0;
                border: 1px solid #555;
                padding: 3px;
            }
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
            }
            QPushButton:hover    { background-color: #45a049; }
            QPushButton:pressed  { background-color: #388e3c; }
            QPushButton:disabled { background-color: #555; color: #888; }
            QLabel               { color: #e0e0e0; }
            QGroupBox {
                border: 1px solid #555;
                border-radius: 4px;
                margin-top: 8px;
                color: #e0e0e0;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 4px;
            }
            QComboBox {
                background-color: #3c3c3c;
                color: #e0e0e0;
                border: 1px solid #555;
                padding: 4px;
            }
            QComboBox::drop-down  { border: none; }
            QComboBox::down-arrow {
                border-left:  5px solid transparent;
                border-right: 5px solid transparent;
                border-top:   5px solid #e0e0e0;
            }
            QMenuBar              { background-color: #2d2d2d; color: #e0e0e0; }
            QMenuBar::item:selected { background-color: #4CAF50; }
            QMenu                 { background-color: #2d2d2d; color: #e0e0e0; border: 1px solid #555; }
            QMenu::item:selected  { background-color: #4CAF50; }
            QScrollArea           { border: none; }
            QScrollBar:vertical   { background-color: #2d2d2d; width: 14px; }
            QScrollBar::handle:vertical {
                background-color: #555;
                min-height: 20px;
                border-radius: 7px;
            }
            QScrollBar::handle:vertical:hover { background-color: #4CAF50; }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
        """)

    # -----------------------------------------------------------------------
    # Connection — helpers
    # -----------------------------------------------------------------------

    def refresh_local_ips(self):
        self.local_ips = get_all_local_ips()
        text = ("  |  ".join(self.local_ips) if len(self.local_ips) <= 3
                else "\n".join(self.local_ips))
        self.local_ip_label.setText(f"Your IPs:  {text}")
        if hasattr(self, 'netinfo_label'):
            self.refresh_netinfo()

    def start_server(self):
        if self.server_listener and self.server_listener.isRunning():
            self.server_listener.stop()
            self.server_listener.wait(2000)
        self.server_listener = ServerListener(self.server_port)
        self.server_listener.new_connection.connect(self.handle_incoming_connection)
        self.server_listener.start()
        self.status_label.setText(
            f"Status: Listening on port {self.server_port} — awaiting peer…"
        )

    def restart_server(self):
        try:
            new_port = int(self.port_input.text().strip())
            if not (1024 <= new_port <= 65535):
                raise ValueError
        except ValueError:
            self.status_label.setText("Status: ❌ Invalid port (must be 1024–65535)")
            return
        self.server_port = new_port
        self.settings.setValue("server_port", new_port)
        if hasattr(self, 'peer_port_input'):
            self.peer_port_input.setText(str(new_port))
        self.start_server()
        self.status_label.setText(
            f"Status: Server restarted on port {self.server_port}"
        )

    # -----------------------------------------------------------------------
    # Connection lifecycle
    # -----------------------------------------------------------------------

    def _teardown_connection(self):
        """Completely tear down all peer resources — safe to call at any time."""
        if self.listener_thread:
            try:
                self.listener_thread.connection_lost.disconnect()
            except Exception:
                pass
            self.listener_thread.stop()
            self.listener_thread.wait(2000)
            self.listener_thread = None

        self.stop_media_stream()

        if self.current_peer_socket:
            self.current_peer_socket.close()
            self.current_peer_socket = None

    def _finalize_connection(self, peer_socket: PeerSocket, peer_addr: str):
        """Wire up a fully-validated peer socket."""
        self.current_peer_socket = peer_socket

        # Send our nickname immediately
        try:
            peer_socket.send_data(
                self.local_nickname.encode('utf-8'), DataPacketType.NICKNAME
            )
        except Exception as e:
            print(f"Warning: could not send nickname: {e}")

        # Start listener
        self.listener_thread = SocketListener(peer_socket)
        self.listener_thread.new_message.connect(self.handle_incoming_message)
        self.listener_thread.new_media.connect(self.handle_incoming_media)
        self.listener_thread.peer_nickname_received.connect(self.handle_incoming_nickname)
        self.listener_thread.connection_lost.connect(self.on_connection_lost)
        self.listener_thread.start()

        # Start media streaming
        self.start_media_stream()

        # Update UI
        self.connect_button.setEnabled(False)
        self.disconnect_button.setEnabled(True)
        self.send_button.setEnabled(True)
        self.tabs.setCurrentIndex(1)   # Jump to Meeting Room

        msg = f"--- Connected to {peer_addr} ---"
        self.chat_history.append(
            f"<span style='color: orange;'>{msg}</span>"
        )
        self.status_label.setText(f"Status: ✅  Call active — {peer_addr}")
        self.update_peer_list_display()

    def handle_incoming_connection(self, peer_socket: PeerSocket):
        """
        Accept an inbound connection from ServerListener.
        Uses a 2-second peek to reject raw TCP probes (e.g. diagnostics self-test).
        """
        try:
            peer_addr = peer_socket.sock.getpeername()
            peer_str  = f"{peer_addr[0]}:{peer_addr[1]}"
        except Exception:
            peer_str = "unknown"

        # Peek: real app handshake arrives within 2 seconds; probes don't send data
        try:
            peer_socket.sock.settimeout(2.0)
            peek = peer_socket.sock.recv(5, socket.MSG_PEEK)
            peer_socket.sock.settimeout(None)
            if not peek:
                print(f"Probe / empty connection from {peer_str} — ignored")
                peer_socket.close()
                return
        except socket.timeout:
            print(f"No data from {peer_str} within 2 s — probe ignored")
            peer_socket.close()
            return
        except Exception as e:
            print(f"Peek error from {peer_str}: {e} — ignored")
            peer_socket.close()
            return

        print(f"✓ Real connection from {peer_str}")

        if self.current_peer_socket is not None:
            print("Replacing existing connection")
            self._teardown_connection()
            self._reset_ui_to_idle()

        self._finalize_connection(peer_socket, peer_str)

    def connect_to_peer(self):
        """Initiate an outbound connection to the peer."""
        peer_ip = self.peer_ip_input.text().strip()
        try:
            peer_port = int(self.peer_port_input.text().strip())
        except ValueError:
            self.status_label.setText("Status: ❌ Invalid port number")
            return
        if not peer_ip:
            self.status_label.setText("Status: ❌ Enter peer IP address first")
            return

        if self.current_peer_socket is not None:
            self._teardown_connection()
            self._reset_ui_to_idle()

        self.status_label.setText(f"Status: Connecting to {peer_ip}:{peer_port}…")
        self.connect_button.setEnabled(False)
        QApplication.processEvents()

        try:
            raw = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            raw.settimeout(15)
            raw.connect((peer_ip, peer_port))
            raw.settimeout(None)
            ps = PeerSocket(raw)
            self._finalize_connection(ps, f"{peer_ip}:{peer_port}")
        except socket.timeout:
            self.status_label.setText(
                f"Status: ❌ Timed out connecting to {peer_ip}:{peer_port}"
            )
            self.connect_button.setEnabled(True)
        except ConnectionRefusedError:
            self.status_label.setText(
                f"Status: ❌ Connection refused — is the app running on the peer?"
            )
            self.connect_button.setEnabled(True)
        except Exception as e:
            self.status_label.setText(f"Status: ❌ Connect error: {e}")
            self.connect_button.setEnabled(True)

    def disconnect_peer(self):
        self._teardown_connection()
        self._reset_ui_to_idle()
        self.status_label.setText(
            f"Status: Disconnected — listening on port {self.server_port}"
        )
        self.chat_history.append(
            "<span style='color: orange;'>--- Disconnected ---</span>"
        )

    def on_connection_lost(self, reason: str):
        self.status_label.setText(f"Status: ❌  {reason}")
        self.chat_history.append(
            f"<span style='color: red;'>--- {reason} ---</span>"
        )
        # Stop media without waiting for listener (it already stopped)
        self.stop_media_stream()
        if self.current_peer_socket:
            self.current_peer_socket.close()
            self.current_peer_socket = None
        self.listener_thread = None
        self._reset_ui_to_idle()

    def _reset_ui_to_idle(self):
        self.connect_button.setEnabled(True)
        self.disconnect_button.setEnabled(False)
        self.send_button.setEnabled(False)
        self.peer_nickname = "Peer"
        self.update_peer_list_display()

    # -----------------------------------------------------------------------
    # Nickname
    # -----------------------------------------------------------------------

    def set_nickname(self):
        name = self.nickname_input.text().strip()
        if name:
            self.local_nickname = name
            self.status_label.setText(f"Status: Nickname set to '{name}'")
            if self.current_peer_socket:
                try:
                    self.current_peer_socket.send_data(
                        name.encode('utf-8'), DataPacketType.NICKNAME
                    )
                except Exception:
                    pass

    def handle_incoming_nickname(self, data: bytes):
        try:
            name = data.decode('utf-8').strip()
            if name:
                self.peer_nickname = name
                self.update_peer_list_display()
                self.chat_history.append(
                    f"<span style='color: orange;'>--- Peer name: {name} ---</span>"
                )
        except Exception:
            pass

    # -----------------------------------------------------------------------
    # Media Streaming
    # -----------------------------------------------------------------------

    def start_media_stream(self):
        if not self.current_peer_socket:
            return

        if self.media_streamer is None:
            self.media_streamer = MediaStreamer(self.current_peer_socket, self.hw_manager)
            self.media_streamer.start()

        if self.audio_playback is None:
            self.audio_playback = AudioPlayback(self.hw_manager)
            self.audio_playback.start()
            time.sleep(0.2)

        self.record_button.setEnabled(True)

    def stop_media_stream(self):
        # Stop streamer first so no more media signals fire before we touch UI
        if self.media_streamer:
            self.media_streamer.stop_stream()
            self.media_streamer = None

        if self.audio_playback:
            self.audio_playback.stop()
            self.audio_playback = None

        if self.is_recording:
            self.is_recording = False
            if self.video_writer:
                self.video_writer.release()
                self.video_writer = None
            # blockSignals prevents toggled → toggle_recording re-entry during teardown
            self.record_button.blockSignals(True)
            self.record_button.setChecked(False)
            self.record_button.setText("⏺️  Record")
            self.record_button.setStyleSheet("")
            self.record_button.blockSignals(False)

        self.audio_recording_data = []
        self.record_button.setEnabled(False)
        self.video_display.clear()
        self.video_display.setText("Stream stopped")

    def _paint_pending_frame(self):
        """Called by QTimer every 30 ms in the main thread — safe to paint."""
        if self._pending_frame is not None:
            self.video_display.set_pixmap(self._pending_frame)
            self._pending_frame = None

    def handle_incoming_media(self, data: bytes):
        """
        Parse a length-prefixed media payload.
        Each chunk: tag_byte (b'A' or b'V') + uint32_be(length) + payload_bytes.
        Multiple chunks may be present in a single packet.
        This avoids delimiter-based parsing where JPEG binary data could contain
        the delimiter sequence and corrupt extraction.
        """
        pos = 0
        n   = len(data)
        while pos < n:
            if pos + 5 > n:
                break
            tag    = data[pos:pos+1]
            length = struct.unpack_from('!I', data, pos + 1)[0]
            pos   += 5
            if pos + length > n:
                break
            chunk = data[pos:pos + length]
            pos  += length

            if tag == b'A':
                # Audio chunk
                try:
                    if self.is_recording:
                        import numpy as np
                        arr = np.frombuffer(chunk, dtype=np.float32)
                        self.audio_recording_data.append(arr.copy())
                    if self.audio_playback:
                        self.audio_playback.add_audio(chunk)
                except Exception:
                    pass

            elif tag == b'V':
                try:
                    import cv2, numpy as np
                    arr   = np.frombuffer(chunk, dtype=np.uint8)
                    frame = cv2.imdecode(arr, cv2.IMREAD_COLOR)
                    if frame is not None:
                        if self.is_recording:
                            try:
                                # Lazy-init: create writer on first frame so we
                                # know the real dimensions — avoids the
                                # hardcoded-size vs actual-size mismatch bug.
                                if self.video_writer is None:
                                    fh, fw = frame.shape[:2]
                                    # Try codecs in order; mp4v works on all platforms,
                                    # XVID is better quality on Windows if available
                                    for codec in (['XVID'] if sys.platform == 'win32' else []) + ['mp4v', 'MJPG']:
                                        fourcc = cv2.VideoWriter_fourcc(*codec)
                                        writer = cv2.VideoWriter(
                                            self.recording_filename, fourcc, 15.0, (fw, fh)
                                        )
                                        if writer.isOpened():
                                            self.video_writer = writer
                                            print(f"✓ Recording: {fw}x{fh} @ 15fps codec={codec}")
                                            break
                                        writer.release()
                                    if self.video_writer is None:
                                        print("✗ Recording: no codec worked, video not saved")
                                if self.video_writer:
                                    self.video_writer.write(frame)
                            except Exception as e:
                                print(f"Recording write error: {e}")
                        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                        rgb = np.ascontiguousarray(rgb)
                        h, w, ch = rgb.shape
                        qimg = QImage(rgb.data, w, h, w * ch, QImage.Format.Format_RGB888).copy()
                        self._pending_frame = QPixmap.fromImage(qimg)
                except Exception as e:
                    import traceback
                    traceback.print_exc()

    def update_mic_indicator(self, muted: bool):
        if self.media_streamer:
            self.media_streamer.is_muted = muted
        if muted:
            self.mic_status_label.setText("Microphone: MUTED 🔇")
            self.mic_status_label.setStyleSheet("color: red; font-weight: bold;")
        else:
            self.mic_status_label.setText("Microphone: ACTIVE 🎙️")
            self.mic_status_label.setStyleSheet("color: #4CAF50; font-weight: bold;")

    def update_video_indicator(self, stopped: bool):
        if self.media_streamer:
            self.media_streamer.video_enabled = not stopped
        if stopped:
            self.video_status_label.setText("Video: PAUSED 🚫")
            self.video_status_label.setStyleSheet("color: orange; font-weight: bold;")
            self.video_display.clear()
            self.video_display.setText("Video paused")
        else:
            self.video_status_label.setText("Video: LIVE 📹")
            self.video_status_label.setStyleSheet("color: #4CAF50; font-weight: bold;")

    def toggle_recording(self, checked: bool):
        if checked:
            try:
                from datetime import datetime
                ts   = datetime.now().strftime("%Y%m%d_%H%M%S")
                home = os.path.expanduser('~')
                self.recording_filename       = os.path.join(home, f"COD_Recording_{ts}.avi")
                self.audio_recording_filename = os.path.join(home, f"COD_Recording_{ts}.wav")
                self.audio_recording_data     = []
                self.video_writer             = None   # lazy-init on first frame
                self.is_recording             = True
                self.record_button.setText("⏹️  Stop Recording")
                self.record_button.setStyleSheet("background-color: #cc0000;")
                self.status_label.setText("Status: 🔴  Recording… (writer opens on first frame)")
            except Exception as e:
                self.record_button.setChecked(False)
                self.status_label.setText(f"Status: ❌  Recording error: {e}")
        else:
            self.is_recording = False
            if self.video_writer:
                self.video_writer.release()
                self.video_writer = None
            self.record_button.setText("⏺️  Record")
            self.record_button.setStyleSheet("")

            if self.audio_recording_data:
                try:
                    import numpy as np
                    audio_arr = np.concatenate(self.audio_recording_data)
                    with wave.open(self.audio_recording_filename, 'wb') as wf:
                        wf.setnchannels(1)
                        wf.setsampwidth(2)
                        wf.setframerate(AudioPlayback.SAMPLE_RATE)
                        audio_i16 = (audio_arr * 32767).astype(np.int16)
                        wf.writeframes(audio_i16.tobytes())

                    # Attempt ffmpeg merge
                    try:
                        import subprocess
                        merged = self.recording_filename.replace('.avi', '_merged.mp4')
                        r = subprocess.run(
                            ['ffmpeg', '-y',
                             '-i', self.recording_filename,
                             '-i', self.audio_recording_filename,
                             '-c:v', 'copy', '-c:a', 'aac', merged],
                            capture_output=True, timeout=30,
                        )
                        if r.returncode == 0:
                            os.remove(self.recording_filename)
                            os.remove(self.audio_recording_filename)
                            self.status_label.setText("Status: ✅  Recording saved (merged)")
                            QMessageBox.information(
                                self, "Recording Saved",
                                f"Saved: {os.path.basename(merged)}\nLocation: {os.path.expanduser('~')}"
                            )
                        else:
                            self.status_label.setText("Status: ✅  Recording saved (separate files)")
                            QMessageBox.information(
                                self, "Recording Saved",
                                f"Video: {os.path.basename(self.recording_filename)}\n"
                                f"Audio: {os.path.basename(self.audio_recording_filename)}\n\n"
                                "Install ffmpeg to auto-merge video + audio."
                            )
                    except FileNotFoundError:
                        self.status_label.setText(
                            "Status: ✅  Recording saved (separate files — ffmpeg not found)"
                        )
                        QMessageBox.information(
                            self, "Recording Saved",
                            f"Video: {os.path.basename(self.recording_filename)}\n"
                            f"Audio: {os.path.basename(self.audio_recording_filename)}\n\n"
                            "Install ffmpeg to auto-merge."
                        )
                except Exception as e:
                    self.status_label.setText(f"Status: ❌  Audio save error: {e}")
            elif self.recording_filename and os.path.exists(self.recording_filename):
                self.status_label.setText("Status: ✅  Recording saved (video only — no audio captured)")
                QMessageBox.information(
                    self, "Recording Saved",
                    f"Saved: {os.path.basename(self.recording_filename)}"
                )
            else:
                self.status_label.setText("Status: Recording stopped")

            self.audio_recording_data = []

    # -----------------------------------------------------------------------
    # Chat
    # -----------------------------------------------------------------------

    def send_message(self):
        if not self.current_peer_socket:
            return
        msg = self.chat_input.text().strip()
        if not msg:
            return
        try:
            self.current_peer_socket.send_data(msg.encode('utf-8'), DataPacketType.CHAT)
            self.chat_history.append(
                f"<span style='color: #4CAF50;'><b>{self.local_nickname}:</b> {msg}</span>"
            )
            self.chat_input.clear()
        except Exception as e:
            self.status_label.setText(f"Status: ❌  Send error: {e}")

    def handle_incoming_message(self, data: bytes):
        try:
            text = data.decode('utf-8')
            self.chat_history.append(
                f"<span style='color: #2196F3;'><b>{self.peer_nickname}:</b> {text}</span>"
            )
        except Exception:
            pass

    # -----------------------------------------------------------------------
    # Device management
    # -----------------------------------------------------------------------

    def update_camera_selection(self, _index):
        self.hw_manager.select_camera(self.camera_combo.currentText())
        if self.media_streamer:
            self.status_label.setText(
                "Status: Camera changed — restart call to pick up new device"
            )

    def update_mic_selection(self, _index):
        self.hw_manager.select_mic(self.mic_combo.currentText())

    def update_speaker_selection(self, _index):
        self.hw_manager.select_speaker(self.speaker_combo.currentText())

    def test_camera(self):
        ok, msg = self.hw_manager.test_camera()
        QMessageBox.information(self, "Camera Test", f"{'✅' if ok else '❌'}  {msg}")

    def test_microphone(self):
        ok, msg = self.hw_manager.test_microphone()
        QMessageBox.information(self, "Microphone Test", f"{'✅' if ok else '❌'}  {msg}")

    def test_speaker(self):
        ok, msg = self.hw_manager.test_speaker()
        QMessageBox.information(self, "Speaker Test", f"{'✅' if ok else '❌'}  {msg}")

    def test_all_hardware(self):
        lines = ["Hardware Test Results:\n"]
        for label, fn in [
            ("Camera",     self.hw_manager.test_camera),
            ("Microphone", self.hw_manager.test_microphone),
            ("Speaker",    self.hw_manager.test_speaker),
        ]:
            ok, msg = fn()
            lines.append(f"{'✅' if ok else '❌'}  {label}: {msg}")
        QMessageBox.information(self, "Hardware Test", "\n".join(lines))

    def update_peer_list_display(self):
        self.peer_list.clear()
        if self.current_peer_socket:
            self.peer_list.addItem(f"👤  {self.peer_nickname}  (connected)")
        else:
            self.peer_list.addItem("(not connected)")

    # -----------------------------------------------------------------------
    # Diagnostics
    # -----------------------------------------------------------------------

    def run_self_test(self):
        self.selftest_result.setText("Testing…")
        QApplication.processEvents()
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(3)
            s.connect(('127.0.0.1', self.server_port))
            s.send(b'\x00')   # Sends data so the peek-probe filter passes, then closes
            s.close()
            self.selftest_result.setText(
                f"✅  PASS — Server is listening on port {self.server_port}. "
                f"Your server is working correctly."
            )
        except ConnectionRefusedError:
            self.selftest_result.setText(
                f"❌  FAIL — Connection refused on port {self.server_port}. "
                f"Server not running? Click Apply Port to restart."
            )
        except socket.timeout:
            self.selftest_result.setText(
                f"❌  FAIL — Timeout on port {self.server_port}."
            )
        except Exception as e:
            self.selftest_result.setText(f"❌  FAIL — {e}")

    def run_reach_test(self):
        peer_ip = self.peer_ip_input.text().strip()
        try:
            port = int(self.peer_port_input.text().strip())
        except ValueError:
            self.reach_result.setText("⚠  Invalid port.")
            return
        if not peer_ip:
            self.reach_result.setText("⚠  Enter peer IP in the Connection tab first.")
            return

        self.reach_result.setText(f"Testing {peer_ip}:{port} …")
        QApplication.processEvents()

        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(5)
            s.connect((peer_ip, port))
            s.close()
            self.reach_result.setText(
                f"✅  PASS — Port {port} is open on {peer_ip}. "
                f"The peer's server is reachable."
            )
        except ConnectionRefusedError:
            self.reach_result.setText(
                f"❌  FAIL — Connection refused.  Port {port} is closed on {peer_ip}.  "
                f"Is Call of Death running on the peer?"
            )
        except socket.timeout:
            self.reach_result.setText(
                f"❌  FAIL — Timeout reaching {peer_ip}:{port}.  "
                f"Most likely: (1) not on the same VPN, "
                f"(2) firewall on peer, (3) wrong IP."
            )
        except OSError as e:
            self.reach_result.setText(
                f"❌  FAIL — {e}.  "
                f"IP {peer_ip} may not be routable from this machine."
            )

    def refresh_netinfo(self):
        ips      = get_all_local_ips()
        peer_ip  = (self.peer_ip_input.text().strip()
                    if hasattr(self, 'peer_ip_input') else "")

        lines = ["=== Your Network Interfaces ==="]
        for ip in ips:
            parts  = ip.split('.')
            subnet = '.'.join(parts[:3]) + '.x'
            lines.append(f"  {ip:<18}  subnet: {subnet:<14}  {tag_ip(ip)}")

        lines += ["", "=== Subnet Compatibility ==="]
        if peer_ip:
            peer_parts = peer_ip.split('.')
            matched    = False
            for ip in ips:
                if ip.split('.')[:3] == peer_parts[:3]:
                    lines.append(
                        f"  ✅  {ip}  and  {peer_ip}  are on the same /24 — direct connect should work"
                    )
                    matched = True
            if not matched:
                lines.append(f"  ❌  {peer_ip} is NOT on the same /24 as any of your IPs")
                lines.append(
                    "       Direct connect will fail unless both are on the same VPN"
                )
        else:
            lines.append("  (enter a peer IP in the Connection tab to check)")

        lines += ["", "=== Server Status ==="]
        if self.server_listener and self.server_listener.isRunning():
            lines.append(f"  ✅  Port {self.server_port} — server thread running")
        else:
            lines.append(
                f"  ❌  Port {self.server_port} — server not running, click Apply Port"
            )

        self.netinfo_label.setText('\n'.join(lines))

    def repair_winsock(self):
        if sys.platform != 'win32':
            self.winsock_result.setText("This repair tool is Windows-only.")
            return
        self.winsock_result.setText("Running repair — a UAC prompt will appear…")
        QApplication.processEvents()
        try:
            import ctypes
            import subprocess
            result = ctypes.windll.shell32.ShellExecuteW(
                None, "runas", "netsh", "winsock reset", None, 1
            )
            if result <= 32:
                self.winsock_result.setText(
                    f"❌  Failed to launch elevated command (code {result}).  "
                    f"Run manually as Admin: netsh winsock reset"
                )
                return
            reply = QMessageBox.question(
                self, "Winsock Reset",
                "Winsock reset command sent.\n\n"
                "You MUST reboot for the fix to take effect.\n\n"
                "Reboot now?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            )
            if reply == QMessageBox.StandardButton.Yes:
                subprocess.run([
                    "shutdown", "/r", "/t", "10", "/c",
                    "Rebooting to complete Winsock repair…",
                ])
                self.winsock_result.setText("Rebooting in 10 seconds… Save your work!")
            else:
                self.winsock_result.setText(
                    "✅  Winsock reset complete — remember to reboot before retrying."
                )
        except Exception as e:
            self.winsock_result.setText(
                f"❌  Error: {e}\nRun manually as Admin: netsh winsock reset"
            )

    # -----------------------------------------------------------------------
    # About
    # -----------------------------------------------------------------------

    def show_about(self):
        QMessageBox.about(
            self, f"About {APP_NAME}",
            f"{APP_NAME}  v1.0\n\n"
            f"© {ORG_NAME}\n\n"
            "Peer-to-peer video & audio calling\n"
            "Designed for ZeroTier and Tailscale VPN networks\n\n"
            "Features:\n"
            "  • Direct P2P video & voice — no relay, no cloud\n"
            "  • Text chat\n"
            "  • Session recording (AVI + WAV, optional ffmpeg merge)\n"
            "  • Network diagnostics with Winsock repair\n\n"
            f"Default port: {DEFAULT_PORT}"
        )


# ===========================================================================
# SPLASH SCREEN
# ===========================================================================

def create_splash():
    try:
        splash_path = Path(resource_path("splash.png"))
        if splash_path.exists():
            pixmap = QPixmap(str(splash_path))
            if pixmap.isNull():
                pixmap = QPixmap(800, 600)
                pixmap.fill(QColor(20, 20, 20))
            if pixmap.width() != 800 or pixmap.height() != 600:
                pixmap = pixmap.scaled(
                    800, 600,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation,
                )
        else:
            pixmap = QPixmap(800, 600)
            pixmap.fill(QColor(20, 20, 20))

        painter = QPainter(pixmap)

        # App name
        painter.setPen(QColor(255, 255, 255))
        painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
        r = pixmap.rect()
        r.setTop(40); r.setBottom(100)
        painter.drawText(r, Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)

        # Skull art (only drawn on generated fallback background)
        if not splash_path.exists():
            painter.setFont(QFont("Courier", 14))
            skull = [
                "        ___________      ",
                "       /           \\    ",
                "      |  O       O  |   ",
                "      |      ^      |   ",
                "      |   \\_____/   |   ",
                "       \\_         _/    ",
                "         |_______|      ",
            ]
            for i, line in enumerate(skull):
                painter.drawText(230, 260 + i * 26, line)

        # Org name
        painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
        fr = pixmap.rect()
        fr.setTop(pixmap.height() - 80); fr.setBottom(pixmap.height() - 30)
        painter.drawText(fr, Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
        painter.end()

        return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)

    except Exception as e:
        print(f"Splash error: {e}")
        return None


# ===========================================================================
# ENTRY POINT
# ===========================================================================

def main():
    if not LIBS_AVAILABLE:
        return

    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(ORG_NAME)

    splash = create_splash()
    if splash:
        splash.show()
        messages = [
            "Initializing Call of Death v1.0…",
            "Detecting cameras and audio devices…",
            "Scanning network interfaces (LAN / ZeroTier / Tailscale)…",
            "Configuring media streaming engine (cv2 / sounddevice)…",
            "Starting TCP server listener…",
            "Configuring socket keepalive and buffer sizes…",
            "Preparing adaptive audio playback buffer (16 kHz)…",
            "Loading network diagnostics module…",
            "System ready — awaiting peer connection…",
        ]
        for msg in messages:
            splash.showMessage(
                "\n\n\n\n\n\n\n" + msg,
                Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignHCenter,
                QColor(255, 255, 255),
            )
            app.processEvents()
            time.sleep(0.5)

    window = CallOfDeath()
    window.show()
    if splash:
        splash.finish(window)

    sys.exit(app.exec())


if __name__ == "__main__":
    # Write all unhandled exceptions to ~/COD_crash.log — essential for
    # diagnosing silent crashes in PyInstaller .app bundles with no console.
    import traceback as _tb
    _log_path = os.path.join(os.path.expanduser("~"), "COD_crash.log")
    try:
        main()
    except Exception as _e:
        _msg = _tb.format_exc()
        try:
            with open(_log_path, "w") as _f:
                _f.write(_msg)
        except Exception:
            pass
        # Also try to show a dialog if Qt is available
        try:
            from PyQt6.QtWidgets import QApplication, QMessageBox
            _app = QApplication.instance() or QApplication(sys.argv)
            QMessageBox.critical(None, "Call of Death — Fatal Error",
                f"The application crashed:\n\n{_e}\n\nDetails saved to:\n{_log_path}")
        except Exception:
            pass
        raise
